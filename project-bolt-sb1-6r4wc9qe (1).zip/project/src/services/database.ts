import { ref, push, set, get, query, orderByChild, equalTo, remove, update } from 'firebase/database';
import { database } from '../config/firebase';
import { Product, ProductFolder, Customer, Sale } from '../types';

export class DatabaseService {
  // Products
  static async addProduct(userId: string, product: Omit<Product, 'id'>): Promise<string> {
    const productsRef = ref(database, `products/${userId}`);
    const newProductRef = push(productsRef);
    await set(newProductRef, {
      ...product,
      totalAmount: product.price * product.quantity
    });
    return newProductRef.key!;
  }

  static async getProducts(userId: string): Promise<Product[]> {
    const productsRef = ref(database, `products/${userId}`);
    const snapshot = await get(productsRef);
    if (snapshot.exists()) {
      return Object.entries(snapshot.val()).map(([id, data]: [string, any]) => ({
        id,
        ...data
      }));
    }
    return [];
  }

  static async updateProduct(userId: string, productId: string, updates: Partial<Product>): Promise<void> {
    const productRef = ref(database, `products/${userId}/${productId}`);
    if (updates.price || updates.quantity) {
      updates.totalAmount = (updates.price || 0) * (updates.quantity || 0);
    }
    await update(productRef, updates);
  }

  static async deleteProduct(userId: string, productId: string): Promise<void> {
    const productRef = ref(database, `products/${userId}/${productId}`);
    await remove(productRef);
  }

  // Product Folders
  static async addProductFolder(userId: string, folder: Omit<ProductFolder, 'id'>): Promise<string> {
    const foldersRef = ref(database, `productFolders/${userId}`);
    const newFolderRef = push(foldersRef);
    await set(newFolderRef, folder);
    return newFolderRef.key!;
  }

  static async getProductFolders(userId: string): Promise<ProductFolder[]> {
    const foldersRef = ref(database, `productFolders/${userId}`);
    const snapshot = await get(foldersRef);
    if (snapshot.exists()) {
      return Object.entries(snapshot.val()).map(([id, data]: [string, any]) => ({
        id,
        ...data
      }));
    }
    return [];
  }

  // Customers
  static async addCustomer(userId: string, customer: Omit<Customer, 'id'>): Promise<string> {
    const customersRef = ref(database, `customers/${userId}`);
    const newCustomerRef = push(customersRef);
    await set(newCustomerRef, {
      ...customer,
      remainingBalance: customer.previousBalance - customer.depositAmount
    });
    return newCustomerRef.key!;
  }

  static async getCustomers(userId: string): Promise<Customer[]> {
    const customersRef = ref(database, `customers/${userId}`);
    const snapshot = await get(customersRef);
    if (snapshot.exists()) {
      return Object.entries(snapshot.val()).map(([id, data]: [string, any]) => ({
        id,
        ...data
      }));
    }
    return [];
  }

  static async updateCustomer(userId: string, customerId: string, updates: Partial<Customer>): Promise<void> {
    const customerRef = ref(database, `customers/${userId}/${customerId}`);
    if (updates.previousBalance !== undefined || updates.depositAmount !== undefined) {
      const snapshot = await get(customerRef);
      const current = snapshot.val();
      updates.remainingBalance = (updates.previousBalance || current.previousBalance) - (updates.depositAmount || current.depositAmount);
    }
    await update(customerRef, updates);
  }

  // Sales
  static async addSale(userId: string, sale: Omit<Sale, 'id'>): Promise<string> {
    const salesRef = ref(database, `sales/${userId}`);
    const newSaleRef = push(salesRef);
    await set(newSaleRef, sale);
    return newSaleRef.key!;
  }

  static async getSales(userId: string): Promise<Sale[]> {
    const salesRef = ref(database, `sales/${userId}`);
    const snapshot = await get(salesRef);
    if (snapshot.exists()) {
      return Object.entries(snapshot.val()).map(([id, data]: [string, any]) => ({
        id,
        ...data
      }));
    }
    return [];
  }

  static async getNextMemoNumber(userId: string): Promise<number> {
    const salesRef = ref(database, `sales/${userId}`);
    const snapshot = await get(salesRef);
    if (snapshot.exists()) {
      const sales = Object.values(snapshot.val()) as Sale[];
      const maxMemoNumber = Math.max(...sales.map(sale => sale.memoNumber), 0);
      return maxMemoNumber + 1;
    }
    return 1;
  }
}