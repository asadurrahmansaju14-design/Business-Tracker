import React, { createContext, useContext, useState, ReactNode } from 'react';

interface LanguageContextType {
  language: 'en' | 'bn';
  toggleLanguage: () => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

const translations = {
  en: {
    // Auth
    'login': 'Login',
    'register': 'Register',
    'email': 'Email',
    'password': 'Password',
    'companyName': 'Company Name',
    'phoneNumber': 'Phone Number',
    'address': 'Address',
    'businessTracker': 'Business Tracker',
    
    // Navigation
    'home': 'Home',
    'productManagement': 'Product Management',
    'customerManagement': 'Customer Management',
    'salesHistory': 'Sales History',
    'stock': 'Stock',
    'memo': 'Memo',
    'dataSave': 'Data Save',
    'language': 'Language',
    
    // Common
    'search': 'Search',
    'add': 'Add',
    'update': 'Update',
    'confirm': 'Confirm',
    'cancel': 'Cancel',
    'delete': 'Delete',
    'save': 'Save',
    'back': 'Back',
    'total': 'Total',
    'quantity': 'Quantity',
    'price': 'Price',
    'name': 'Name',
    'date': 'Date',
    'time': 'Time',
    
    // Product
    'productName': 'Product Name',
    'productNumber': 'Product Number',
    'unit': 'Unit',
    'pieces': 'Pieces',
    'dozen': 'Dozen',
    'kg': 'KG',
    'packet': 'Packet',
    'folder': 'Folder',
    'addProduct': 'Add Product',
    'productSearch': 'Product Search',
    
    // Customer
    'customerName': 'Customer Name',
    'previousBalance': 'Previous Balance',
    'depositAmount': 'Deposit Amount',
    'remainingBalance': 'Remaining Balance',
    'addCustomer': 'Add Customer',
    'customerSearch': 'Customer Search',
    
    // Memo
    'memoNumber': 'Memo Number',
    'sellConfirmed': 'Sell Confirmed',
    'serial': 'Serial',
    'totalAmount': 'Total Amount',
    
    // Stock
    'stockValue': 'Stock Value',
    'lowStock': 'Low Stock Alert',
    'increaseStock': 'Increase Stock'
  },
  bn: {
    // Auth
    'login': 'লগইন',
    'register': 'নিবন্ধন',
    'email': 'ইমেইল',
    'password': 'পাসওয়ার্ড',
    'companyName': 'কোম্পানির নাম',
    'phoneNumber': 'ফোন নম্বর',
    'address': 'ঠিকানা',
    'businessTracker': 'ব্যবসা ট্র্যাকার',
    
    // Navigation
    'home': 'হোম',
    'productManagement': 'পণ্য ব্যবস্থাপনা',
    'customerManagement': 'গ্রাহক ব্যবস্থাপনা',
    'salesHistory': 'বিক্রয়ের ইতিহাস',
    'stock': 'স্টক',
    'memo': 'মেমো',
    'dataSave': 'ডেটা সেভ',
    'language': 'ভাষা',
    
    // Common
    'search': 'খুঁজুন',
    'add': 'যোগ করুন',
    'update': 'আপডেট',
    'confirm': 'নিশ্চিত করুন',
    'cancel': 'বাতিল',
    'delete': 'মুছুন',
    'save': 'সেভ করুন',
    'back': 'ফিরে যান',
    'total': 'মোট',
    'quantity': 'পরিমাণ',
    'price': 'দাম',
    'name': 'নাম',
    'date': 'তারিখ',
    'time': 'সময়',
    
    // Product
    'productName': 'পণ্যের নাম',
    'productNumber': 'পণ্য নম্বর',
    'unit': 'একক',
    'pieces': 'পিস',
    'dozen': 'ডজন',
    'kg': 'কেজি',
    'packet': 'প্যাকেট',
    'folder': 'ফোল্ডার',
    'addProduct': 'পণ্য যোগ করুন',
    'productSearch': 'পণ্য খুঁজুন',
    
    // Customer
    'customerName': 'গ্রাহকের নাম',
    'previousBalance': 'পূর্ববর্তী ব্যালেন্স',
    'depositAmount': 'জমার পরিমাণ',
    'remainingBalance': 'অবশিষ্ট ব্যালেন্স',
    'addCustomer': 'গ্রাহক যোগ করুন',
    'customerSearch': 'গ্রাহক খুঁজুন',
    
    // Memo
    'memoNumber': 'মেমো নম্বর',
    'sellConfirmed': 'বিক্রয় নিশ্চিত',
    'serial': 'ক্রমিক',
    'totalAmount': 'মোট পরিমাণ',
    
    // Stock
    'stockValue': 'স্টক মূল্য',
    'lowStock': 'কম স্টক সতর্কতা',
    'increaseStock': 'স্টক বৃদ্ধি'
  }
};

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<'en' | 'bn'>('en');

  const toggleLanguage = () => {
    setLanguage(prev => prev === 'en' ? 'bn' : 'en');
  };

  const t = (key: string): string => {
    return translations[language][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, toggleLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};