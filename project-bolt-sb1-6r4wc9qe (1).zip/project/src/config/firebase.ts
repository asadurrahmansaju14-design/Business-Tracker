import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getDatabase } from 'firebase/database';
import { getAnalytics } from 'firebase/analytics';

const firebaseConfig = {
  apiKey: "AIzaSyAylEnnkfCAg75SfkeRHR4lk74vQnQOE4M",
  authDomain: "business-e835e.firebaseapp.com",
  databaseURL: "https://business-e835e-default-rtdb.firebaseio.com",
  projectId: "business-e835e",
  storageBucket: "business-e835e.firebasestorage.app",
  messagingSenderId: "484357258128",
  appId: "1:484357258128:web:ae6a631dc65c47fa2f9115",
  measurementId: "G-7VS0G2364G"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const database = getDatabase(app);
export const analytics = getAnalytics(app);
export default app;