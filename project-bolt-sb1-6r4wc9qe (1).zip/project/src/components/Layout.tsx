import React, { ReactNode } from 'react';
import { ArrowLeft, MoreVertical, Home, Package, Users, BarChart3, Archive, FileText, Save, Globe } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';

interface LayoutProps {
  children: ReactNode;
  showBackButton?: boolean;
  showMenu?: boolean;
  title?: string;
}

export const Layout: React.FC<LayoutProps> = ({ children, showBackButton = false, showMenu = false, title }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const { currentUser, logout } = useAuth();
  const { t, toggleLanguage, language } = useLanguage();
  const [menuOpen, setMenuOpen] = React.useState(false);

  const menuItems = [
    { icon: Home, label: t('home'), path: '/home', color: 'text-rose-300' },
    { icon: Package, label: t('productManagement'), path: '/products' },
    { icon: Users, label: t('customerManagement'), path: '/customers' },
    { icon: BarChart3, label: t('salesHistory'), path: '/sales' },
    { icon: Archive, label: t('stock'), path: '/stock' },
    { icon: FileText, label: t('memo'), path: '/memo' },
    { icon: Save, label: t('dataSave'), path: '/data-save' },
  ];

  const handleMenuClick = (path: string) => {
    navigate(path);
    setMenuOpen(false);
  };

  const handleLanguageToggle = () => {
    toggleLanguage();
    setMenuOpen(false);
  };

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Left side */}
            <div className="flex items-center">
              {showBackButton && (
                <button
                  onClick={() => navigate(-1)}
                  className="mr-4 p-2 rounded-lg hover:bg-gray-100 transition-colors"
                >
                  <ArrowLeft className="h-5 w-5 text-gray-600" />
                </button>
              )}
              {title && (
                <h1 className="text-xl font-semibold text-gray-900">{title}</h1>
              )}
            </div>

            {/* Center - Company Info */}
            {currentUser && location.pathname === '/home' && (
              <div className="text-center">
                <h1 className="text-2xl font-bold text-gray-900">{currentUser.companyName}</h1>
                <p className="text-sm text-gray-600">{currentUser.address}</p>
                <p className="text-sm text-gray-600">{currentUser.phoneNumber}</p>
              </div>
            )}

            {/* Right side */}
            <div className="flex items-center space-x-4">
              {showMenu && (
                <div className="relative">
                  <button
                    onClick={() => setMenuOpen(!menuOpen)}
                    className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
                  >
                    <MoreVertical className="h-5 w-5 text-gray-600" />
                  </button>

                  {/* Dropdown Menu */}
                  {menuOpen && (
                    <div className="absolute right-0 mt-2 w-56 bg-white rounded-lg shadow-lg border border-gray-200 z-50">
                      <div className="py-2">
                        {menuItems.map((item) => (
                          <button
                            key={item.path}
                            onClick={() => handleMenuClick(item.path)}
                            className={`w-full flex items-center px-4 py-2 text-sm hover:bg-gray-50 transition-colors ${
                              item.color || 'text-gray-700'
                            }`}
                          >
                            <item.icon className="h-4 w-4 mr-3" />
                            {item.label}
                          </button>
                        ))}
                        <hr className="my-2 border-gray-200" />
                        <button
                          onClick={handleLanguageToggle}
                          className="w-full flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 transition-colors"
                        >
                          <Globe className="h-4 w-4 mr-3" />
                          {t('language')} ({language === 'en' ? 'বাংলা' : 'English'})
                        </button>
                        <button
                          onClick={handleLogout}
                          className="w-full flex items-center px-4 py-2 text-sm text-red-600 hover:bg-red-50 transition-colors"
                        >
                          Logout
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {children}
      </main>

      {/* Click outside to close menu */}
      {menuOpen && (
        <div
          className="fixed inset-0 z-40"
          onClick={() => setMenuOpen(false)}
        />
      )}
    </div>
  );
};