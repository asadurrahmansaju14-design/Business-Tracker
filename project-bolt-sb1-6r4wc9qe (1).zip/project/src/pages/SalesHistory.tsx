import React, { useState, useEffect } from 'react';
import { Layout } from '../components/Layout';
import { SearchBar } from '../components/SearchBar';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { DatabaseService } from '../services/database';
import { Sale } from '../types';
import { FileText, Calendar, User, DollarSign } from 'lucide-react';

export const SalesHistory: React.FC = () => {
  const { t } = useLanguage();
  const { currentUser } = useAuth();
  const [sales, setSales] = useState<Sale[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [dateFilter, setDateFilter] = useState('');
  const [selectedSale, setSelectedSale] = useState<Sale | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadSales();
  }, [currentUser]);

  const loadSales = async () => {
    if (!currentUser) return;
    
    setLoading(true);
    try {
      const salesData = await DatabaseService.getSales(currentUser.uid);
      setSales(salesData.sort((a, b) => b.memoNumber - a.memoNumber));
    } catch (error) {
      console.error('Error loading sales:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = () => {
    // Search functionality is handled by filtering in render
  };

  const filteredSales = sales.filter(sale => {
    const matchesSearch = !searchQuery || 
      sale.memoNumber.toString().includes(searchQuery) ||
      sale.customerName.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesDate = !dateFilter || sale.date === new Date(dateFilter).toLocaleDateString();
    
    return matchesSearch && matchesDate;
  });

  const totalRevenue = filteredSales.reduce((sum, sale) => sum + sale.totalAmount, 0);

  return (
    <Layout showBackButton={true} showMenu={true} title={t('salesHistory')}>
      <div className="max-w-6xl mx-auto">
        {/* Filters */}
        <div className="bg-white rounded-xl shadow-sm p-6 mb-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Search by Memo Number or Customer</label>
              <SearchBar
                placeholder="Enter memo number or customer name..."
                value={searchQuery}
                onChange={setSearchQuery}
                onSearch={handleSearch}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Filter by Date</label>
              <input
                type="date"
                value={dateFilter}
                onChange={(e) => setDateFilter(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>

          {/* Summary */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-blue-50 p-4 rounded-lg">
              <div className="flex items-center">
                <FileText className="h-5 w-5 text-blue-600 mr-2" />
                <div>
                  <p className="text-sm text-gray-600">Total Sales</p>
                  <p className="text-xl font-bold text-blue-600">{filteredSales.length}</p>
                </div>
              </div>
            </div>
            <div className="bg-green-50 p-4 rounded-lg">
              <div className="flex items-center">
                <DollarSign className="h-5 w-5 text-green-600 mr-2" />
                <div>
                  <p className="text-sm text-gray-600">Total Revenue</p>
                  <p className="text-xl font-bold text-green-600">৳{totalRevenue}</p>
                </div>
              </div>
            </div>
            <div className="bg-purple-50 p-4 rounded-lg">
              <div className="flex items-center">
                <Calendar className="h-5 w-5 text-purple-600 mr-2" />
                <div>
                  <p className="text-sm text-gray-600">Today</p>
                  <p className="text-xl font-bold text-purple-600">
                    {sales.filter(s => s.date === new Date().toLocaleDateString()).length}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Sales List */}
        {loading ? (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredSales.map((sale) => (
              <div key={sale.id} className="bg-white rounded-xl shadow-sm p-6 hover:shadow-md transition-shadow">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="bg-blue-100 p-3 rounded-lg">
                      <FileText className="h-6 w-6 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900">Memo #{sale.memoNumber}</h3>
                      <div className="flex items-center text-sm text-gray-600 mt-1">
                        <User className="h-4 w-4 mr-1" />
                        {sale.customerName}
                        <Calendar className="h-4 w-4 ml-4 mr-1" />
                        {sale.date} {sale.time}
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <p className="text-lg font-bold text-green-600">৳{sale.totalAmount}</p>
                    <p className="text-sm text-gray-500">{sale.products.length} items</p>
                  </div>
                </div>

                <button
                  onClick={() => setSelectedSale(sale)}
                  className="mt-4 text-blue-600 hover:text-blue-700 text-sm font-medium"
                >
                  View Details →
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Sale Detail Modal */}
        {selectedSale && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-xl p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold">Memo #{selectedSale.memoNumber}</h3>
                <button
                  onClick={() => setSelectedSale(null)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  ✕
                </button>
              </div>

              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-600">Customer</p>
                    <p className="font-medium">{selectedSale.customerName}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Date & Time</p>
                    <p className="font-medium">{selectedSale.date} {selectedSale.time}</p>
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-2">Products</h4>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-3 py-2 text-left">Product</th>
                          <th className="px-3 py-2 text-left">Qty</th>
                          <th className="px-3 py-2 text-left">Price</th>
                          <th className="px-3 py-2 text-left">Total</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-200">
                        {selectedSale.products.map((product) => (
                          <tr key={product.id}>
                            <td className="px-3 py-2">{product.name}</td>
                            <td className="px-3 py-2">{product.quantity} {product.unit}</td>
                            <td className="px-3 py-2">৳{product.price}</td>
                            <td className="px-3 py-2 font-semibold">৳{product.totalAmount}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                <div className="bg-gray-50 rounded-lg p-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-gray-600">Total Amount:</p>
                      <p className="text-lg font-bold">৳{selectedSale.totalAmount}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Previous Balance:</p>
                      <p className="text-lg font-bold text-red-600">৳{selectedSale.previousBalance}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Deposit:</p>
                      <p className="text-lg font-bold text-green-600">৳{selectedSale.depositAmount}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Remaining Balance:</p>
                      <p className={`text-lg font-bold ${selectedSale.remainingBalance > 0 ? 'text-red-600' : 'text-green-600'}`}>
                        ৳{selectedSale.remainingBalance}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
};