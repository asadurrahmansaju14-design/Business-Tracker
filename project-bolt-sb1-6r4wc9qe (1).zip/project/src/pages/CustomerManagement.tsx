import React, { useState, useEffect } from 'react';
import { Layout } from '../components/Layout';
import { SearchBar } from '../components/SearchBar';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { DatabaseService } from '../services/database';
import { Customer } from '../types';
import { Users, Plus, Edit, Phone, MapPin, DollarSign } from 'lucide-react';

export const CustomerManagement: React.FC = () => {
  const { t } = useLanguage();
  const { currentUser } = useAuth();
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [loading, setLoading] = useState(false);

  const [customerForm, setCustomerForm] = useState({
    name: '',
    address: '',
    phoneNumber: '',
    previousBalance: '',
    depositAmount: '',
    depositDate: new Date().toISOString().split('T')[0]
  });

  useEffect(() => {
    loadCustomers();
  }, [currentUser]);

  const loadCustomers = async () => {
    if (!currentUser) return;
    
    setLoading(true);
    try {
      const customersData = await DatabaseService.getCustomers(currentUser.uid);
      setCustomers(customersData);
    } catch (error) {
      console.error('Error loading customers:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAddCustomer = async () => {
    if (!currentUser || !customerForm.name) return;

    try {
      await DatabaseService.addCustomer(currentUser.uid, {
        name: customerForm.name,
        address: customerForm.address,
        phoneNumber: customerForm.phoneNumber,
        previousBalance: parseFloat(customerForm.previousBalance) || 0,
        depositAmount: parseFloat(customerForm.depositAmount) || 0,
        depositDate: customerForm.depositDate,
        remainingBalance: 0, // Will be calculated in the service
        userId: currentUser.uid
      });

      setCustomerForm({
        name: '',
        address: '',
        phoneNumber: '',
        previousBalance: '',
        depositAmount: '',
        depositDate: new Date().toISOString().split('T')[0]
      });
      setShowAddModal(false);
      loadCustomers();
    } catch (error) {
      console.error('Error adding customer:', error);
    }
  };

  const handleSearch = () => {
    // Search functionality is handled by filtering in render
  };

  const filteredCustomers = customers.filter(customer =>
    customer.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    customer.phoneNumber.includes(searchQuery)
  );

  return (
    <Layout showBackButton={true} showMenu={true} title={t('customerManagement')}>
      <div className="max-w-6xl mx-auto">
        {/* Header Actions */}
        <div className="flex justify-between items-center mb-6">
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Plus className="h-4 w-4 mr-2" />
            {t('addCustomer')}
          </button>
        </div>

        {/* Search */}
        <SearchBar
          placeholder={t('customerSearch')}
          value={searchQuery}
          onChange={setSearchQuery}
          onSearch={handleSearch}
        />

        {/* Customers List */}
        {loading ? (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredCustomers.map((customer) => (
              <div key={customer.id} className="bg-white rounded-xl shadow-sm p-6 hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center">
                    <div className="bg-blue-100 p-2 rounded-lg mr-3">
                      <Users className="h-5 w-5 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900">{customer.name}</h3>
                    </div>
                  </div>
                  <button className="p-1 text-gray-400 hover:text-blue-600 transition-colors">
                    <Edit className="h-4 w-4" />
                  </button>
                </div>

                <div className="space-y-2 text-sm">
                  <div className="flex items-center text-gray-600">
                    <MapPin className="h-4 w-4 mr-2" />
                    {customer.address || 'No address'}
                  </div>
                  <div className="flex items-center text-gray-600">
                    <Phone className="h-4 w-4 mr-2" />
                    {customer.phoneNumber || 'No phone'}
                  </div>
                </div>

                <div className="mt-4 pt-4 border-t border-gray-200">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-gray-500">{t('previousBalance')}</p>
                      <p className="font-semibold text-gray-900">৳{customer.previousBalance}</p>
                    </div>
                    <div>
                      <p className="text-gray-500">{t('remainingBalance')}</p>
                      <p className={`font-semibold ${customer.remainingBalance > 0 ? 'text-red-600' : 'text-green-600'}`}>
                        ৳{customer.remainingBalance}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Add Customer Modal */}
        {showAddModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-xl p-6 w-full max-w-md max-h-[90vh] overflow-y-auto">
              <h3 className="text-lg font-semibold mb-4">{t('addCustomer')}</h3>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">{t('customerName')}</label>
                  <input
                    type="text"
                    value={customerForm.name}
                    onChange={(e) => setCustomerForm({ ...customerForm, name: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">{t('address')}</label>
                  <textarea
                    value={customerForm.address}
                    onChange={(e) => setCustomerForm({ ...customerForm, address: e.target.value })}
                    rows={2}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">{t('phoneNumber')}</label>
                  <input
                    type="tel"
                    value={customerForm.phoneNumber}
                    onChange={(e) => setCustomerForm({ ...customerForm, phoneNumber: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">{t('previousBalance')}</label>
                  <input
                    type="number"
                    value={customerForm.previousBalance}
                    onChange={(e) => setCustomerForm({ ...customerForm, previousBalance: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">{t('depositAmount')}</label>
                  <input
                    type="number"
                    value={customerForm.depositAmount}
                    onChange={(e) => setCustomerForm({ ...customerForm, depositAmount: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Deposit Date</label>
                  <input
                    type="date"
                    value={customerForm.depositDate}
                    onChange={(e) => setCustomerForm({ ...customerForm, depositDate: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>

              <div className="flex space-x-3 mt-6">
                <button
                  onClick={handleAddCustomer}
                  className="flex-1 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition-colors"
                >
                  {t('confirm')}
                </button>
                <button
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 bg-gray-300 text-gray-700 py-2 rounded-lg hover:bg-gray-400 transition-colors"
                >
                  {t('cancel')}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
};