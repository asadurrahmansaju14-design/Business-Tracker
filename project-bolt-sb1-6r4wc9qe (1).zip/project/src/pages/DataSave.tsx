import React, { useState } from 'react';
import { Layout } from '../components/Layout';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { DatabaseService } from '../services/database';
import { Download, Upload, Database, CheckCircle } from 'lucide-react';

export const DataSave: React.FC = () => {
  const { t } = useLanguage();
  const { currentUser } = useAuth();
  const [loading, setLoading] = useState(false);
  const [lastBackup, setLastBackup] = useState<string | null>(null);

  const handleBackup = async () => {
    if (!currentUser) return;

    setLoading(true);
    try {
      const [products, customers, sales] = await Promise.all([
        DatabaseService.getProducts(currentUser.uid),
        DatabaseService.getCustomers(currentUser.uid),
        DatabaseService.getSales(currentUser.uid)
      ]);

      const backupData = {
        timestamp: new Date().toISOString(),
        products,
        customers,
        sales,
        company: {
          name: currentUser.companyName,
          phone: currentUser.phoneNumber,
          address: currentUser.address,
          email: currentUser.email
        }
      };

      const dataStr = JSON.stringify(backupData, null, 2);
      const dataBlob = new Blob([dataStr], { type: 'application/json' });
      const url = URL.createObjectURL(dataBlob);
      
      const link = document.createElement('a');
      link.href = url;
      link.download = `business-backup-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      URL.revokeObjectURL(url);
      setLastBackup(new Date().toLocaleString());
    } catch (error) {
      console.error('Backup error:', error);
      alert('Error creating backup');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Layout showBackButton={true} showMenu={true} title={t('dataSave')}>
      <div className="max-w-2xl mx-auto">
        <div className="bg-white rounded-xl shadow-sm p-8">
          <div className="text-center mb-8">
            <div className="bg-blue-100 p-4 rounded-full w-16 h-16 mx-auto mb-4">
              <Database className="h-8 w-8 text-blue-600 mx-auto mt-1" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Data Management</h2>
            <p className="text-gray-600">Backup and manage your business data</p>
          </div>

          {/* Automatic Save Status */}
          <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
            <div className="flex items-center">
              <CheckCircle className="h-5 w-5 text-green-600 mr-3" />
              <div>
                <h3 className="font-semibold text-green-800">Automatic Data Saving</h3>
                <p className="text-sm text-green-700">All your data is automatically saved to Firebase in real-time</p>
              </div>
            </div>
          </div>

          {/* Backup Section */}
          <div className="space-y-4">
            <div className="bg-gray-50 rounded-lg p-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="font-semibold text-gray-900">Manual Backup</h3>
                  <p className="text-sm text-gray-600">Download a backup of all your business data</p>
                </div>
                <Download className="h-5 w-5 text-gray-500" />
              </div>
              
              <button
                onClick={handleBackup}
                disabled={loading}
                className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed font-medium"
              >
                {loading ? 'Creating Backup...' : 'Download Backup'}
              </button>
              
              {lastBackup && (
                <p className="text-sm text-gray-500 mt-2">Last backup: {lastBackup}</p>
              )}
            </div>

            {/* Data Summary */}
            <div className="bg-gray-50 rounded-lg p-6">
              <h3 className="font-semibold text-gray-900 mb-4">Data Summary</h3>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-gray-600">Products:</p>
                  <p className="font-semibold">Loading...</p>
                </div>
                <div>
                  <p className="text-gray-600">Customers:</p>
                  <p className="font-semibold">Loading...</p>
                </div>
                <div>
                  <p className="text-gray-600">Sales:</p>
                  <p className="font-semibold">Loading...</p>
                </div>
                <div>
                  <p className="text-gray-600">Stock Value:</p>
                  <p className="font-semibold">৳0</p>
                </div>
              </div>
            </div>

            {/* Data Security Info */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <h4 className="font-semibold text-blue-800 mb-2">Data Security</h4>
              <ul className="text-sm text-blue-700 space-y-1">
                <li>• All data is encrypted and stored securely in Firebase</li>
                <li>• Real-time synchronization across devices</li>
                <li>• Automatic backups every 24 hours</li>
                <li>• Download manual backups anytime</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};