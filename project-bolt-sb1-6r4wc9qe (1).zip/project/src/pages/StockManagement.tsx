import React, { useState, useEffect } from 'react';
import { Layout } from '../components/Layout';
import { SearchBar } from '../components/SearchBar';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { DatabaseService } from '../services/database';
import { Product, ProductFolder } from '../types';
import { Package, AlertTriangle, Plus, TrendingUp } from 'lucide-react';

export const StockManagement: React.FC = () => {
  const { t } = useLanguage();
  const { currentUser } = useAuth();
  const [products, setProducts] = useState<Product[]>([]);
  const [folders, setFolders] = useState<ProductFolder[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [increaseAmount, setIncreaseAmount] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadData();
  }, [currentUser]);

  const loadData = async () => {
    if (!currentUser) return;
    
    setLoading(true);
    try {
      const [productsData, foldersData] = await Promise.all([
        DatabaseService.getProducts(currentUser.uid),
        DatabaseService.getProductFolders(currentUser.uid)
      ]);
      setProducts(productsData);
      setFolders(foldersData);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleIncreaseStock = async () => {
    if (!currentUser || !selectedProduct || !increaseAmount) return;

    try {
      const newQuantity = selectedProduct.quantity + parseInt(increaseAmount);
      await DatabaseService.updateProduct(currentUser.uid, selectedProduct.id, {
        quantity: newQuantity
      });
      
      setSelectedProduct(null);
      setIncreaseAmount('');
      loadData();
    } catch (error) {
      console.error('Error updating stock:', error);
    }
  };

  const handleSearch = () => {
    // Search functionality is handled by filtering in render
  };

  const filteredProducts = products.filter(product =>
    product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    product.productNumber.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const groupedProducts = filteredProducts.reduce((acc, product) => {
    const folder = folders.find(f => f.id === product.folderId);
    const folderName = folder ? folder.name : 'Uncategorized';
    
    if (!acc[folderName]) {
      acc[folderName] = [];
    }
    acc[folderName].push(product);
    return acc;
  }, {} as Record<string, Product[]>);

  const lowStockProducts = products.filter(product => product.quantity <= 5);
  const totalStockValue = products.reduce((sum, product) => sum + product.totalAmount, 0);

  return (
    <Layout showBackButton={true} showMenu={true} title={t('stock')}>
      <div className="max-w-6xl mx-auto">
        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex items-center">
              <div className="bg-blue-100 p-3 rounded-lg mr-4">
                <Package className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Total Products</p>
                <p className="text-2xl font-bold text-blue-600">{products.length}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex items-center">
              <div className="bg-green-100 p-3 rounded-lg mr-4">
                <TrendingUp className="h-6 w-6 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">{t('stockValue')}</p>
                <p className="text-2xl font-bold text-green-600">৳{totalStockValue}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex items-center">
              <div className="bg-red-100 p-3 rounded-lg mr-4">
                <AlertTriangle className="h-6 w-6 text-red-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">{t('lowStock')}</p>
                <p className="text-2xl font-bold text-red-600">{lowStockProducts.length}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Low Stock Alert */}
        {lowStockProducts.length > 0 && (
          <div className="bg-red-50 border border-red-200 rounded-xl p-4 mb-6">
            <div className="flex items-center mb-3">
              <AlertTriangle className="h-5 w-5 text-red-600 mr-2" />
              <h3 className="font-semibold text-red-800">Low Stock Alert</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {lowStockProducts.map((product) => (
                <div key={product.id} className="bg-white p-3 rounded-lg">
                  <p className="font-medium text-gray-900">{product.name}</p>
                  <p className="text-sm text-red-600">Only {product.quantity} {product.unit} left</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Search */}
        <SearchBar
          placeholder="Search products..."
          value={searchQuery}
          onChange={setSearchQuery}
          onSearch={handleSearch}
        />

        {/* Stock by Folder */}
        {loading ? (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          </div>
        ) : (
          <div className="space-y-6">
            {Object.entries(groupedProducts).map(([folderName, folderProducts]) => (
              <div key={folderName} className="bg-white rounded-xl shadow-sm overflow-hidden">
                <div className="bg-gray-50 px-6 py-3 border-b border-gray-200">
                  <h3 className="font-semibold text-gray-900">{folderName}</h3>
                </div>
                
                <div className="divide-y divide-gray-200">
                  {folderProducts.map((product) => (
                    <div key={product.id} className="p-6 hover:bg-gray-50 transition-colors">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                          <div className={`p-2 rounded-lg ${product.quantity <= 5 ? 'bg-red-100' : 'bg-green-100'}`}>
                            <Package className={`h-5 w-5 ${product.quantity <= 5 ? 'text-red-600' : 'text-green-600'}`} />
                          </div>
                          <div>
                            <h4 className="font-medium text-gray-900">{product.name}</h4>
                            <p className="text-sm text-gray-500">#{product.productNumber}</p>
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-6">
                          <div className="text-center">
                            <p className={`text-lg font-bold ${product.quantity <= 5 ? 'text-red-600' : 'text-gray-900'}`}>
                              {product.quantity}
                            </p>
                            <p className="text-xs text-gray-500">{product.unit}</p>
                          </div>
                          <div className="text-center">
                            <p className="text-lg font-bold text-green-600">৳{product.totalAmount}</p>
                            <p className="text-xs text-gray-500">Value</p>
                          </div>
                          <button
                            onClick={() => setSelectedProduct(product)}
                            className="flex items-center px-3 py-1 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm"
                          >
                            <Plus className="h-4 w-4 mr-1" />
                            {t('increaseStock')}
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Increase Stock Modal */}
        {selectedProduct && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-xl p-6 w-full max-w-md">
              <h3 className="text-lg font-semibold mb-4">{t('increaseStock')}</h3>
              
              <div className="mb-4">
                <p className="font-medium text-gray-900">{selectedProduct.name}</p>
                <p className="text-sm text-gray-600">Current stock: {selectedProduct.quantity} {selectedProduct.unit}</p>
              </div>

              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">Increase by</label>
                <input
                  type="number"
                  value={increaseAmount}
                  onChange={(e) => setIncreaseAmount(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Enter amount to add"
                />
              </div>

              {increaseAmount && (
                <div className="mb-4 p-3 bg-blue-50 rounded-lg">
                  <p className="text-sm text-gray-600">New stock will be:</p>
                  <p className="font-bold text-blue-600">
                    {selectedProduct.quantity + parseInt(increaseAmount)} {selectedProduct.unit}
                  </p>
                </div>
              )}

              <div className="flex space-x-3">
                <button
                  onClick={handleIncreaseStock}
                  className="flex-1 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition-colors"
                >
                  {t('confirm')}
                </button>
                <button
                  onClick={() => setSelectedProduct(null)}
                  className="flex-1 bg-gray-300 text-gray-700 py-2 rounded-lg hover:bg-gray-400 transition-colors"
                >
                  {t('cancel')}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
};