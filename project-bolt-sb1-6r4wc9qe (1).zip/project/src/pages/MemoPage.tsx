import React, { useState, useEffect } from 'react';
import { Layout } from '../components/Layout';
import { SearchBar } from '../components/SearchBar';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { DatabaseService } from '../services/database';
import { Product, Customer, Sale, SaleProduct } from '../types';
import { FileText, Plus, Trash2, Building2 } from 'lucide-react';

export const MemoPage: React.FC = () => {
  const { t, language } = useLanguage();
  const { currentUser } = useAuth();
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [memoProducts, setMemoProducts] = useState<SaleProduct[]>([]);
  const [productSearchQuery, setProductSearchQuery] = useState('');
  const [customerSearchQuery, setCustomerSearchQuery] = useState('');
  const [depositAmount, setDepositAmount] = useState('');
  const [memoNumber, setMemoNumber] = useState(1);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadData();
  }, [currentUser]);

  const loadData = async () => {
    if (!currentUser) return;
    
    try {
      const [customersData, productsData, nextMemoNum] = await Promise.all([
        DatabaseService.getCustomers(currentUser.uid),
        DatabaseService.getProducts(currentUser.uid),
        DatabaseService.getNextMemoNumber(currentUser.uid)
      ]);
      setCustomers(customersData);
      setProducts(productsData);
      setMemoNumber(nextMemoNum);
    } catch (error) {
      console.error('Error loading data:', error);
    }
  };

  const handleCustomerSelect = (customer: Customer) => {
    setSelectedCustomer(customer);
    setCustomerSearchQuery(customer.name);
  };

  const handleProductAdd = (product: Product) => {
    const existingIndex = memoProducts.findIndex(p => p.id === product.id);
    
    if (existingIndex > -1) {
      const updated = [...memoProducts];
      updated[existingIndex].quantity += 1;
      updated[existingIndex].totalAmount = updated[existingIndex].quantity * updated[existingIndex].price;
      setMemoProducts(updated);
    } else {
      const newProduct: SaleProduct = {
        id: product.id,
        name: product.name,
        quantity: 1,
        unit: product.unit,
        price: product.price,
        totalAmount: product.price
      };
      setMemoProducts([...memoProducts, newProduct]);
    }
    setProductSearchQuery('');
  };

  const updateProductQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      setMemoProducts(memoProducts.filter(p => p.id !== productId));
      return;
    }

    setMemoProducts(memoProducts.map(p =>
      p.id === productId
        ? { ...p, quantity, totalAmount: quantity * p.price }
        : p
    ));
  };

  const removeProduct = (productId: string) => {
    setMemoProducts(memoProducts.filter(p => p.id !== productId));
  };

  const calculateTotals = () => {
    const totalAmount = memoProducts.reduce((sum, product) => sum + product.totalAmount, 0);
    const previousBalance = selectedCustomer?.remainingBalance || 0;
    const deposit = parseFloat(depositAmount) || 0;
    const finalBalance = totalAmount + previousBalance - deposit;

    return { totalAmount, previousBalance, deposit, finalBalance };
  };

  const handleSellConfirmed = async () => {
    if (!currentUser || !selectedCustomer || memoProducts.length === 0) return;

    setLoading(true);
    try {
      const { totalAmount, previousBalance, deposit, finalBalance } = calculateTotals();
      
      const sale: Omit<Sale, 'id'> = {
        memoNumber,
        customerId: selectedCustomer.id,
        customerName: selectedCustomer.name,
        products: memoProducts,
        totalAmount,
        previousBalance,
        depositAmount: deposit,
        remainingBalance: finalBalance,
        date: new Date().toLocaleDateString(),
        time: new Date().toLocaleTimeString(),
        userId: currentUser.uid
      };

      await DatabaseService.addSale(currentUser.uid, sale);

      // Update customer balance
      await DatabaseService.updateCustomer(currentUser.uid, selectedCustomer.id, {
        remainingBalance: finalBalance,
        depositAmount: deposit,
        depositDate: new Date().toISOString().split('T')[0]
      });

      // Update product stock
      for (const product of memoProducts) {
        const originalProduct = products.find(p => p.id === product.id);
        if (originalProduct) {
          await DatabaseService.updateProduct(currentUser.uid, product.id, {
            quantity: originalProduct.quantity - product.quantity
          });
        }
      }

      // Reset form
      setMemoProducts([]);
      setSelectedCustomer(null);
      setCustomerSearchQuery('');
      setDepositAmount('');
      setMemoNumber(memoNumber + 1);
      
      alert('Sale completed successfully!');
    } catch (error) {
      console.error('Error completing sale:', error);
      alert('Error completing sale');
    } finally {
      setLoading(false);
    }
  };

  const filteredProducts = products.filter(product =>
    product.name.toLowerCase().includes(productSearchQuery.toLowerCase()) ||
    product.productNumber.toLowerCase().includes(productSearchQuery.toLowerCase())
  );

  const filteredCustomers = customers.filter(customer =>
    customer.name.toLowerCase().includes(customerSearchQuery.toLowerCase())
  );

  const { totalAmount, previousBalance, deposit, finalBalance } = calculateTotals();

  return (
    <Layout showBackButton={true} showMenu={true} title={t('memo')}>
      <div className="max-w-4xl mx-auto">
        {/* Memo Header */}
        <div className="bg-white rounded-xl shadow-sm p-6 mb-6">
          <div className="text-center mb-6">
            <p className="text-sm text-gray-600 mb-2">بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيْمِ</p>
            <div className="flex items-center justify-between">
              <div className="text-left">
                <Building2 className="h-8 w-8 text-blue-600 mb-2" />
                <p className="text-sm font-medium">#{memoNumber}</p>
              </div>
              <div className="text-center">
                <h1 className="text-2xl font-bold text-gray-900">{currentUser?.companyName}</h1>
                <p className="text-lg font-semibold text-gray-700 mt-1">
                  {language === 'bn' ? 'মেমো' : 'MEMO'}
                </p>
              </div>
              <div className="text-right">
                <p className="text-sm font-medium">{currentUser?.phoneNumber}</p>
                <p className="text-sm text-gray-600">{currentUser?.address}</p>
                <p className="text-sm text-gray-600">{new Date().toLocaleDateString()}</p>
                <p className="text-sm text-gray-600">{new Date().toLocaleTimeString()}</p>
              </div>
            </div>
          </div>

          {/* Customer Selection */}
          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">{t('customerName')}</label>
            <div className="relative">
              <input
                type="text"
                value={customerSearchQuery}
                onChange={(e) => setCustomerSearchQuery(e.target.value)}
                placeholder="Search and select customer..."
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              {customerSearchQuery && filteredCustomers.length > 0 && !selectedCustomer && (
                <div className="absolute z-10 w-full mt-1 bg-white border border-gray-300 rounded-lg shadow-lg max-h-40 overflow-y-auto">
                  {filteredCustomers.map((customer) => (
                    <button
                      key={customer.id}
                      onClick={() => handleCustomerSelect(customer)}
                      className="w-full text-left px-4 py-2 hover:bg-gray-50 transition-colors"
                    >
                      <div className="font-medium">{customer.name}</div>
                      <div className="text-sm text-gray-500">{customer.address}</div>
                    </button>
                  ))}
                </div>
              )}
            </div>
            {selectedCustomer && (
              <div className="mt-2 p-3 bg-blue-50 rounded-lg">
                <p className="font-medium">{selectedCustomer.name}</p>
                <p className="text-sm text-gray-600">{selectedCustomer.address}</p>
                <p className="text-sm text-gray-600">{selectedCustomer.phoneNumber}</p>
              </div>
            )}
          </div>

          {/* Product Search */}
          <div className="mb-6">
            <SearchBar
              placeholder="Search products to add..."
              value={productSearchQuery}
              onChange={setProductSearchQuery}
              onSearch={() => {}}
            />
            
            {productSearchQuery && filteredProducts.length > 0 && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-40 overflow-y-auto">
                {filteredProducts.map((product) => (
                  <button
                    key={product.id}
                    onClick={() => handleProductAdd(product)}
                    className="text-left p-3 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    <div className="font-medium">{product.name}</div>
                    <div className="text-sm text-gray-500">
                      #{product.productNumber} | ৳{product.price} | {product.quantity} {product.unit}
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Products Table */}
          {memoProducts.length > 0 && (
            <div className="mb-6">
              <h3 className="font-semibold text-gray-900 mb-3">Selected Products</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-3 py-2 text-left font-medium text-gray-700">{t('serial')}</th>
                      <th className="px-3 py-2 text-left font-medium text-gray-700">{t('productName')}</th>
                      <th className="px-3 py-2 text-left font-medium text-gray-700">{t('quantity')}</th>
                      <th className="px-3 py-2 text-left font-medium text-gray-700">{t('price')}</th>
                      <th className="px-3 py-2 text-left font-medium text-gray-700">{t('total')}</th>
                      <th className="px-3 py-2 text-left font-medium text-gray-700">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {memoProducts.map((product, index) => (
                      <tr key={product.id}>
                        <td className="px-3 py-2">{index + 1}</td>
                        <td className="px-3 py-2 font-medium">{product.name}</td>
                        <td className="px-3 py-2">
                          <input
                            type="number"
                            value={product.quantity}
                            onChange={(e) => updateProductQuantity(product.id, parseInt(e.target.value) || 0)}
                            className="w-16 px-2 py-1 border border-gray-300 rounded text-center"
                            min="1"
                          />
                          <span className="ml-1 text-gray-500">{product.unit}</span>
                        </td>
                        <td className="px-3 py-2">৳{product.price}</td>
                        <td className="px-3 py-2 font-semibold">৳{product.totalAmount}</td>
                        <td className="px-3 py-2">
                          <button
                            onClick={() => removeProduct(product.id)}
                            className="text-red-600 hover:text-red-700 p-1"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Payment Section */}
          <div className="bg-gray-50 rounded-lg p-4">
            <div className="grid grid-cols-2 gap-4 text-sm mb-4">
              <div>
                <p className="text-gray-600">{t('totalAmount')}:</p>
                <p className="text-xl font-bold text-gray-900">৳{totalAmount}</p>
              </div>
              <div>
                <p className="text-gray-600">{t('previousBalance')}:</p>
                <p className="text-lg font-semibold text-red-600">৳{previousBalance}</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">{t('depositAmount')}</label>
                <input
                  type="number"
                  value={depositAmount}
                  onChange={(e) => setDepositAmount(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <p className="text-sm text-gray-600 mb-1">{t('remainingBalance')}:</p>
                <p className={`text-xl font-bold ${finalBalance > 0 ? 'text-red-600' : 'text-green-600'}`}>
                  ৳{finalBalance}
                </p>
              </div>
            </div>

            <button
              onClick={handleSellConfirmed}
              disabled={loading || !selectedCustomer || memoProducts.length === 0}
              className="w-full bg-green-600 text-white py-3 rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed font-medium"
            >
              {loading ? 'Processing...' : t('sellConfirmed')}
            </button>
          </div>
        </div>
      </div>
    </Layout>
  );
};