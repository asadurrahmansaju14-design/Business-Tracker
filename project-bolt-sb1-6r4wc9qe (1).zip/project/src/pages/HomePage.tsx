import React, { useState } from 'react';
import { Layout } from '../components/Layout';
import { SearchBar } from '../components/SearchBar';
import { useLanguage } from '../contexts/LanguageContext';
import { DatabaseService } from '../services/database';
import { useAuth } from '../contexts/AuthContext';
import { Product } from '../types';

export const HomePage: React.FC = () => {
  const { t } = useLanguage();
  const { currentUser } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Product[]>([]);
  const [loading, setLoading] = useState(false);

  const handleSearch = async () => {
    if (!searchQuery.trim() || !currentUser) return;
    
    setLoading(true);
    try {
      const products = await DatabaseService.getProducts(currentUser.uid);
      const filtered = products.filter(product =>
        product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.productNumber.toLowerCase().includes(searchQuery.toLowerCase())
      );
      setSearchResults(filtered);
    } catch (error) {
      console.error('Search error:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Layout showMenu={true}>
      <div className="max-w-2xl mx-auto">
        {/* Search Section */}
        <div className="bg-white rounded-xl shadow-sm p-6 mb-8">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">{t('productSearch')}</h2>
          <SearchBar
            placeholder="Search products by name or number..."
            value={searchQuery}
            onChange={setSearchQuery}
            onSearch={handleSearch}
          />

          {/* Search Results */}
          {loading && (
            <div className="text-center py-4">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
            </div>
          )}

          {searchResults.length > 0 && (
            <div className="space-y-3">
              <h3 className="font-medium text-gray-900">Search Results:</h3>
              {searchResults.map((product) => (
                <div key={product.id} className="bg-gray-50 rounded-lg p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-medium text-gray-900">{product.name}</h4>
                      <p className="text-sm text-gray-600">#{product.productNumber}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold text-gray-900">৳{product.price}</p>
                      <p className="text-sm text-gray-600">{product.quantity} {product.unit}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {searchQuery && !loading && searchResults.length === 0 && (
            <div className="text-center py-8 text-gray-500">
              No products found for "{searchQuery}"
            </div>
          )}
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white rounded-xl shadow-sm p-6 text-center">
            <div className="text-2xl font-bold text-blue-600 mb-2">0</div>
            <div className="text-sm text-gray-600">Total Products</div>
          </div>
          <div className="bg-white rounded-xl shadow-sm p-6 text-center">
            <div className="text-2xl font-bold text-green-600 mb-2">0</div>
            <div className="text-sm text-gray-600">Total Customers</div>
          </div>
        </div>
      </div>
    </Layout>
  );
};