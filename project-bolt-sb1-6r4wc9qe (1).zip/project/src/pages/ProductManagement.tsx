import React, { useState, useEffect } from 'react';
import { Layout } from '../components/Layout';
import { SearchBar } from '../components/SearchBar';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { DatabaseService } from '../services/database';
import { Product, ProductFolder } from '../types';
import { Package, Plus, Edit, Trash2, Folder } from 'lucide-react';

export const ProductManagement: React.FC = () => {
  const { t } = useLanguage();
  const { currentUser } = useAuth();
  const [products, setProducts] = useState<Product[]>([]);
  const [folders, setFolders] = useState<ProductFolder[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showFolderModal, setShowFolderModal] = useState(false);
  const [loading, setLoading] = useState(false);

  // Product form states
  const [productForm, setProductForm] = useState({
    name: '',
    price: '',
    quantity: '',
    unit: 'pieces' as const,
    productNumber: '',
    folderId: ''
  });

  const [folderName, setFolderName] = useState('');

  useEffect(() => {
    loadData();
  }, [currentUser]);

  const loadData = async () => {
    if (!currentUser) return;
    
    setLoading(true);
    try {
      const [productsData, foldersData] = await Promise.all([
        DatabaseService.getProducts(currentUser.uid),
        DatabaseService.getProductFolders(currentUser.uid)
      ]);
      setProducts(productsData);
      setFolders(foldersData);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAddFolder = async () => {
    if (!folderName.trim() || !currentUser) return;

    try {
      await DatabaseService.addProductFolder(currentUser.uid, {
        name: folderName,
        userId: currentUser.uid
      });
      setFolderName('');
      setShowFolderModal(false);
      loadData();
    } catch (error) {
      console.error('Error adding folder:', error);
    }
  };

  const handleAddProduct = async () => {
    if (!currentUser || !productForm.name || !productForm.price || !productForm.quantity) return;

    try {
      await DatabaseService.addProduct(currentUser.uid, {
        name: productForm.name,
        price: parseFloat(productForm.price),
        quantity: parseInt(productForm.quantity),
        unit: productForm.unit,
        productNumber: productForm.productNumber,
        folderId: productForm.folderId,
        totalAmount: 0 // Will be calculated in the service
      });

      setProductForm({
        name: '',
        price: '',
        quantity: '',
        unit: 'pieces',
        productNumber: '',
        folderId: ''
      });
      setShowAddModal(false);
      loadData();
    } catch (error) {
      console.error('Error adding product:', error);
    }
  };

  const handleSearch = () => {
    // Search functionality is handled by filtering in render
  };

  const filteredProducts = products.filter(product =>
    product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    product.productNumber.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const groupedProducts = filteredProducts.reduce((acc, product) => {
    const folder = folders.find(f => f.id === product.folderId);
    const folderName = folder ? folder.name : 'Uncategorized';
    
    if (!acc[folderName]) {
      acc[folderName] = [];
    }
    acc[folderName].push(product);
    return acc;
  }, {} as Record<string, Product[]>);

  return (
    <Layout showBackButton={true} showMenu={true} title={t('productManagement')}>
      <div className="max-w-6xl mx-auto">
        {/* Header Actions */}
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <button
            onClick={() => setShowFolderModal(true)}
            className="flex items-center px-4 py-2 bg-teal-600 text-white rounded-lg hover:bg-teal-700 transition-colors"
          >
            <Folder className="h-4 w-4 mr-2" />
            Add Folder
          </button>
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Plus className="h-4 w-4 mr-2" />
            {t('addProduct')}
          </button>
        </div>

        {/* Search */}
        <SearchBar
          placeholder={t('productSearch')}
          value={searchQuery}
          onChange={setSearchQuery}
          onSearch={handleSearch}
        />

        {/* Products by Folder */}
        {loading ? (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          </div>
        ) : (
          <div className="space-y-6">
            {Object.entries(groupedProducts).map(([folderName, folderProducts]) => (
              <div key={folderName} className="bg-white rounded-xl shadow-sm overflow-hidden">
                <div className="bg-gray-50 px-6 py-3 border-b border-gray-200">
                  <div className="flex items-center">
                    <Folder className="h-5 w-5 text-gray-500 mr-2" />
                    <h3 className="font-semibold text-gray-900">{folderName}</h3>
                    <span className="ml-2 bg-gray-200 text-gray-700 px-2 py-1 rounded-full text-xs">
                      {folderProducts.length} products
                    </span>
                  </div>
                </div>
                
                <div className="divide-y divide-gray-200">
                  {folderProducts.map((product) => (
                    <div key={product.id} className="p-6 hover:bg-gray-50 transition-colors">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                          <div className="bg-blue-100 p-2 rounded-lg">
                            <Package className="h-5 w-5 text-blue-600" />
                          </div>
                          <div>
                            <h4 className="font-medium text-gray-900">{product.name}</h4>
                            <p className="text-sm text-gray-500">#{product.productNumber}</p>
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-6">
                          <div className="text-right">
                            <p className="font-semibold text-gray-900">৳{product.price}</p>
                            <p className="text-sm text-gray-500">{product.quantity} {product.unit}</p>
                          </div>
                          <div className="text-right">
                            <p className="font-bold text-green-600">৳{product.totalAmount}</p>
                            <p className="text-xs text-gray-500">{t('total')}</p>
                          </div>
                          <div className="flex space-x-2">
                            <button className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
                              <Edit className="h-4 w-4" />
                            </button>
                            <button className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors">
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Add Folder Modal */}
        {showFolderModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-xl p-6 w-full max-w-md">
              <h3 className="text-lg font-semibold mb-4">Add New Folder</h3>
              <input
                type="text"
                value={folderName}
                onChange={(e) => setFolderName(e.target.value)}
                placeholder="Folder name"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent mb-4"
              />
              <div className="flex space-x-3">
                <button
                  onClick={handleAddFolder}
                  className="flex-1 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition-colors"
                >
                  {t('confirm')}
                </button>
                <button
                  onClick={() => setShowFolderModal(false)}
                  className="flex-1 bg-gray-300 text-gray-700 py-2 rounded-lg hover:bg-gray-400 transition-colors"
                >
                  {t('cancel')}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Add Product Modal */}
        {showAddModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-xl p-6 w-full max-w-md">
              <h3 className="text-lg font-semibold mb-4">{t('addProduct')}</h3>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Folder</label>
                  <select
                    value={productForm.folderId}
                    onChange={(e) => setProductForm({ ...productForm, folderId: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="">Select folder</option>
                    {folders.map((folder) => (
                      <option key={folder.id} value={folder.id}>{folder.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">{t('productName')}</label>
                  <input
                    type="text"
                    value={productForm.name}
                    onChange={(e) => setProductForm({ ...productForm, name: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">{t('productNumber')}</label>
                  <input
                    type="text"
                    value={productForm.productNumber}
                    onChange={(e) => setProductForm({ ...productForm, productNumber: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">{t('price')}</label>
                    <input
                      type="number"
                      value={productForm.price}
                      onChange={(e) => setProductForm({ ...productForm, price: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">{t('quantity')}</label>
                    <input
                      type="number"
                      value={productForm.quantity}
                      onChange={(e) => setProductForm({ ...productForm, quantity: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">{t('unit')}</label>
                  <select
                    value={productForm.unit}
                    onChange={(e) => setProductForm({ ...productForm, unit: e.target.value as any })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="pieces">{t('pieces')}</option>
                    <option value="dozen">{t('dozen')}</option>
                    <option value="kg">{t('kg')}</option>
                    <option value="packet">{t('packet')}</option>
                  </select>
                </div>
              </div>

              <div className="flex space-x-3 mt-6">
                <button
                  onClick={handleAddProduct}
                  className="flex-1 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition-colors"
                >
                  {t('confirm')}
                </button>
                <button
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 bg-gray-300 text-gray-700 py-2 rounded-lg hover:bg-gray-400 transition-colors"
                >
                  {t('cancel')}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
};