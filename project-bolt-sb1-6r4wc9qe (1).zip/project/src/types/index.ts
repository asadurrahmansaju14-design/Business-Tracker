export interface User {
  uid: string;
  email: string;
  companyName: string;
  phoneNumber: string;
  address: string;
}

export interface Product {
  id: string;
  name: string;
  price: number;
  quantity: number;
  unit: 'pieces' | 'dozen' | 'kg' | 'packet';
  productNumber: string;
  folderId: string;
  totalAmount: number;
}

export interface ProductFolder {
  id: string;
  name: string;
  userId: string;
}

export interface Customer {
  id: string;
  name: string;
  address: string;
  phoneNumber: string;
  previousBalance: number;
  depositAmount: number;
  depositDate: string;
  remainingBalance: number;
  userId: string;
}

export interface Sale {
  id: string;
  memoNumber: number;
  customerId: string;
  customerName: string;
  products: SaleProduct[];
  totalAmount: number;
  previousBalance: number;
  depositAmount: number;
  remainingBalance: number;
  date: string;
  time: string;
  userId: string;
}

export interface SaleProduct {
  id: string;
  name: string;
  quantity: number;
  unit: string;
  price: number;
  totalAmount: number;
}

export interface Language {
  code: 'en' | 'bn';
  name: string;
}